package com.example.backend_carrito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendCarritoApplicationTests {

	@Test
	void contextLoads() {
	}

}
