package com.example.backend_carrito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendCarritoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendCarritoApplication.class, args);
	}

}
